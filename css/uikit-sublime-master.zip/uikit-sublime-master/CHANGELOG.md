# Changelog

### 2.0.1 (January 19, 2017)
  - added missing files

### 2.0.0 (January 19, 2017)
  - updated for UIkit 3
  - removed snippets, because none exists for UIkit 3 at this point
  - added build script

### 1.13.0 (February 25, 2015)
  - updated for UIkit 2.25.0

### 1.12.0 (April 29, 2015)
  - updated for UIkit 2.20.1

### 1.11.0 (April 20, 2015)
  - updated for UIkit 2.19.0

### 1.10.0 (March 31, 2015)
  - updated for UIkit 2.18.0
  - fixed completions not working when inside first class attribute of a document (issue #6)

### 1.9.0 (February 9, 2015)
  - updated for UIkit 2.17.0

### 1.8.0 (December 8, 2014)
  - updated for UIkit 2.13.1

### 1.7.0 (October 7, 2014)
  - updated for UIkit 2.11.0

### 1.6.0 (August 8, 2014)
  - updated for UIkit 2.9.0
  - added markup snippets (triggered when typing `uikit`)

### 1.5.0 (June 6, 2014)
  - updated for UIkit 2.7.0

### 1.4.0 (May 9, 2014)
  - updated for UIkit 2.6.0

### 1.3.0 (March 25, 2014)
  - updated for UIkit 2.5.0

### 1.2.0 (March 5, 2014)
  - updated for UIkit 2.4.0
  - included addons

### 1.1.0 (February 21, 2014)
  - updated for UIkit 2.3.1

### 1.0.0 (January 24, 2014)
  - initial release
